using Microsoft.EntityFrameworkCore;
using BATTLEGAME.Backend.Models;

namespace BATTLEGAME.Backend.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Player> Player { get; set; }
        public DbSet<Asset> Asset { get; set; }
        public DbSet<PlayerAsset> PlayerAsset { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PlayerAsset>()
                .HasKey(pa => new { pa.PlayerId, pa.AssetId });

            modelBuilder.Entity<PlayerAsset>()
                .HasOne(pa => pa.Player)
                .WithMany()
                .HasForeignKey(pa => pa.PlayerId);

            modelBuilder.Entity<PlayerAsset>()
                .HasOne(pa => pa.Asset)
                .WithMany()
                .HasForeignKey(pa => pa.AssetId);

            base.OnModelCreating(modelBuilder);
        }
    }
}
