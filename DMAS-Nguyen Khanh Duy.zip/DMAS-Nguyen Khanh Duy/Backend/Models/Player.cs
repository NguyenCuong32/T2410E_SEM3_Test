using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BATTLEGAME.Backend.Models
{
    public class Player
    {
        [Key]
        public Guid PlayerId { get; set; }

        [Required]
        [MaxLength(64)]
        public string PlayerName { get; set; }

        [MaxLength(128)]
        public string? FullName { get; set; }

        [MaxLength(10)]
        public string? Age { get; set; }

        public int Level { get; set; }

        [MaxLength(64)]
        public string? Email { get; set; }
    }
}
