using System;
using System.ComponentModel.DataAnnotations;

namespace BATTLEGAME.Backend.Models
{
    public class Asset
    {
        [Key]
        public Guid AssetId { get; set; }

        [Required]
        [MaxLength(64)]
        public string AssetName { get; set; }

        public int LevelRequire { get; set; }
    }
}
