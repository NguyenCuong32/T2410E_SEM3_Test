using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ComicSystem.Data;
using ComicSystem.Models;
namespace ComicSystem.Controllers
{
    public class RentalsController : Controller
    {
        private readonly ComicSystemContext _context;
        public RentalsController(ComicSystemContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Index()
        {
            var comicSystemContext = _context.Rentals.Include(r => r.Customer);
            return View(await comicSystemContext.ToListAsync());
        }
        public IActionResult Create()
        {
            ViewData["CustomerID"] = new SelectList(_context.Customers, "CustomerID", "FullName");
            ViewData["ComicBookID"] = new SelectList(_context.ComicBooks, "ComicBookID", "Title");
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("RentalID,CustomerID,ReturnDate")] Rental rental, int ComicBookID, int Quantity)
        {
            if (ModelState.IsValid)
            {
                rental.RentalDate = DateTime.Now;
                rental.Status = "Rented";
                _context.Add(rental);
                await _context.SaveChangesAsync();
                var comicBook = await _context.ComicBooks.FindAsync(ComicBookID);
                if (comicBook != null)
                {
                    var rentalDetail = new RentalDetail
                    {
                        RentalID = rental.RentalID,
                        ComicBookID = ComicBookID,
                        Quantity = Quantity,
                        PricePerDay = comicBook.PricePerDay
                    };
                    _context.Add(rentalDetail);
                    await _context.SaveChangesAsync();
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CustomerID"] = new SelectList(_context.Customers, "CustomerID", "FullName", rental.CustomerID);
            ViewData["ComicBookID"] = new SelectList(_context.ComicBooks, "ComicBookID", "Title", ComicBookID);
            return View(rental);
        }
    }
}
