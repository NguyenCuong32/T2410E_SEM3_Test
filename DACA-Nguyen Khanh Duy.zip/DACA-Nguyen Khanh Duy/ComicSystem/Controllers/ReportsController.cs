using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ComicSystem.Data;
using ComicSystem.Models;
namespace ComicSystem.Controllers
{
    public class ReportsController : Controller
    {
        private readonly ComicSystemContext _context;
        public ReportsController(ComicSystemContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Index(DateTime? startDate, DateTime? endDate)
        {
            var query = _context.RentalDetails.Include(rd => rd.Rental).Include(rd => rd.ComicBook).Include(rd => rd.Rental.Customer).AsQueryable();
            if (startDate.HasValue) query = query.Where(rd => rd.Rental.RentalDate >= startDate.Value);
            if (endDate.HasValue) query = query.Where(rd => rd.Rental.RentalDate <= endDate.Value);
            ViewData["StartDate"] = startDate?.ToString("yyyy-MM-dd");
            ViewData["EndDate"] = endDate?.ToString("yyyy-MM-dd");
            return View(await query.ToListAsync());
        }
    }
}
